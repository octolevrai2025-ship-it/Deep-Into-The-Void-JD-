package net.mcreator.jamdrops.item;

import net.minecraft.world.item.Item;

public class UnknownCrystalItem extends Item {
	public UnknownCrystalItem() {
		super(new Item.Properties());
	}
}