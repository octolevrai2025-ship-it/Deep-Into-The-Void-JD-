package net.mcreator.jamdrops.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.Entity;

import net.mcreator.jamdrops.procedures.ShinyHeartQuandLitemEstDansLinventaireParTickProcedure;

public class ShinyHeartItem extends Item {
	public ShinyHeartItem() {
		super(new Item.Properties().stacksTo(1).fireResistant());
	}

	@Override
	public void inventoryTick(ItemStack itemstack, Level world, Entity entity, int slot, boolean selected) {
		super.inventoryTick(itemstack, world, entity, slot, selected);
		if (selected)
			ShinyHeartQuandLitemEstDansLinventaireParTickProcedure.execute(entity);
	}
}