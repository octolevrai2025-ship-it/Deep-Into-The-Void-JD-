package net.mcreator.jamdrops.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.Entity;

import net.mcreator.jamdrops.procedures.DarkCrystalQuandLitemEstDansLinventaireParTickProcedure;

public class DarkCrystalItem extends Item {
	public DarkCrystalItem() {
		super(new Item.Properties().durability(24000).fireResistant());
	}

	@Override
	public void inventoryTick(ItemStack itemstack, Level world, Entity entity, int slot, boolean selected) {
		super.inventoryTick(itemstack, world, entity, slot, selected);
		DarkCrystalQuandLitemEstDansLinventaireParTickProcedure.execute(world, itemstack);
	}
}