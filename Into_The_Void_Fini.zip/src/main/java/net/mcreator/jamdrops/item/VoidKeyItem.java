package net.mcreator.jamdrops.item;

import net.minecraft.world.item.Item;

public class VoidKeyItem extends Item {
	public VoidKeyItem() {
		super(new Item.Properties().durability(100).fireResistant());
	}
}