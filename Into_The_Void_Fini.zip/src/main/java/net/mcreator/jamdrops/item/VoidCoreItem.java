package net.mcreator.jamdrops.item;

import net.minecraft.world.item.Item;

public class VoidCoreItem extends Item {
	public VoidCoreItem() {
		super(new Item.Properties());
	}
}