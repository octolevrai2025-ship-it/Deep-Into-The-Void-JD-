package net.mcreator.jamdrops.item;

import net.minecraft.world.item.Item;

public class CorruptCoreItem extends Item {
	public CorruptCoreItem() {
		super(new Item.Properties());
	}
}