package net.mcreator.jamdrops.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class VoidShardItem extends Item {
	public VoidShardItem() {
		super(new Item.Properties().fireResistant().rarity(Rarity.RARE));
	}
}