package net.mcreator.jamdrops.client.model.animations;

import net.minecraft.client.animation.KeyframeAnimations;
import net.minecraft.client.animation.Keyframe;
import net.minecraft.client.animation.AnimationDefinition;
import net.minecraft.client.animation.AnimationChannel;

// Save this class in your mod and generate all required imports
/**
 * Made with Blockbench 5.1.4 Exported for Minecraft version 1.19 or later with
 * Mojang mappings
 * 
 * @author Author
 */
public class portailleAnimation {
	public static final AnimationDefinition annimationportaille = AnimationDefinition.Builder.withLength(14.0F).looping()
			.addAnimation("anneau",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(0.0F, KeyframeAnimations.degreeVec(-65.2151F, -38.8447F, 53.6397F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(7.0F, KeyframeAnimations.degreeVec(54.5922F, -55.7003F, 280.2139F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(14.0F, KeyframeAnimations.degreeVec(-65.2151F, -38.8447F, 53.6397F), AnimationChannel.Interpolations.LINEAR)))
			.addAnimation("Orbit",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, -17.5F, -12.5F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(7.0F, KeyframeAnimations.degreeVec(355.1508F, -11.5349F, -349.5099F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(14.0F, KeyframeAnimations.degreeVec(0.0F, -17.5F, -12.5F), AnimationChannel.Interpolations.LINEAR)))
			.build();
}