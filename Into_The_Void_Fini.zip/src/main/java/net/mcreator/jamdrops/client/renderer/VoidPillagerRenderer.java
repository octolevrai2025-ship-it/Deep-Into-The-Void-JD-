package net.mcreator.jamdrops.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.jamdrops.entity.VoidPillagerEntity;
import net.mcreator.jamdrops.client.model.ModelVoidPillager;

public class VoidPillagerRenderer extends MobRenderer<VoidPillagerEntity, ModelVoidPillager<VoidPillagerEntity>> {
	private final ResourceLocation entityTexture = ResourceLocation.parse("deep_into_the_void:textures/entities/void_pillager.png");

	public VoidPillagerRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelVoidPillager<VoidPillagerEntity>(context.bakeLayer(ModelVoidPillager.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(VoidPillagerEntity entity) {
		return entityTexture;
	}
}