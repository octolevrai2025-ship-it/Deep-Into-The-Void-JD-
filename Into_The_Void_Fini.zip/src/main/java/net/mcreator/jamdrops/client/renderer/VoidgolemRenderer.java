package net.mcreator.jamdrops.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.jamdrops.entity.VoidgolemEntity;
import net.mcreator.jamdrops.client.model.Modelvoidgolem;

public class VoidgolemRenderer extends MobRenderer<VoidgolemEntity, Modelvoidgolem<VoidgolemEntity>> {
	private final ResourceLocation entityTexture = ResourceLocation.parse("deep_into_the_void:textures/entities/void_golem.png");

	public VoidgolemRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelvoidgolem<VoidgolemEntity>(context.bakeLayer(Modelvoidgolem.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(VoidgolemEntity entity) {
		return entityTexture;
	}
}