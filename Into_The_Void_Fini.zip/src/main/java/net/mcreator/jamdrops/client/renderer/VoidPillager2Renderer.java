package net.mcreator.jamdrops.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.jamdrops.entity.VoidPillager2Entity;
import net.mcreator.jamdrops.client.model.ModelVoidPillager;

public class VoidPillager2Renderer extends MobRenderer<VoidPillager2Entity, ModelVoidPillager<VoidPillager2Entity>> {
	private final ResourceLocation entityTexture = ResourceLocation.parse("deep_into_the_void:textures/entities/void_pillager.png");

	public VoidPillager2Renderer(EntityRendererProvider.Context context) {
		super(context, new ModelVoidPillager<VoidPillager2Entity>(context.bakeLayer(ModelVoidPillager.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(VoidPillager2Entity entity) {
		return entityTexture;
	}
}