package net.mcreator.jamdrops.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.jamdrops.entity.AnciengolemEntity;
import net.mcreator.jamdrops.client.model.ModelGolemAncien;

public class AnciengolemRenderer extends MobRenderer<AnciengolemEntity, ModelGolemAncien<AnciengolemEntity>> {
	private final ResourceLocation entityTexture = ResourceLocation.parse("deep_into_the_void:textures/entities/ancien_golem.png");

	public AnciengolemRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelGolemAncien<AnciengolemEntity>(context.bakeLayer(ModelGolemAncien.LAYER_LOCATION)), 1f);
	}

	@Override
	public ResourceLocation getTextureLocation(AnciengolemEntity entity) {
		return entityTexture;
	}
}