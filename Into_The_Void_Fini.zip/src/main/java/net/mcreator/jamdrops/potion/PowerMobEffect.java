package net.mcreator.jamdrops.potion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ParticleOptions;

import net.mcreator.jamdrops.procedures.PowerQuandLeffetCommenceEstAppliqueProcedure;

public class PowerMobEffect extends MobEffect {
	public PowerMobEffect() {
		super(MobEffectCategory.NEUTRAL, -227841);
	}

	@Override
	public ParticleOptions createParticleOptions(MobEffectInstance mobEffectInstance) {
		return ParticleTypes.ELECTRIC_SPARK;
	}

	@Override
	public void onEffectStarted(LivingEntity entity, int amplifier) {
		PowerQuandLeffetCommenceEstAppliqueProcedure.execute(entity.level());
	}
}