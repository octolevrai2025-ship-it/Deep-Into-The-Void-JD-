package net.mcreator.jamdrops.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;

import net.mcreator.jamdrops.network.DeepIntoTheVoidModVariables;

public class VoidgolemQuandLeJoueurEntreEnCollisionAvecLentiteProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (DeepIntoTheVoidModVariables.MapVariables.get(world).Vie_Golem < 0) {
			if (world instanceof Level _level && !_level.isClientSide())
				_level.explode(null, x, y, z, 2, Level.ExplosionInteraction.MOB);
		}
	}
}