package net.mcreator.jamdrops.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.jamdrops.network.DeepIntoTheVoidModVariables;

public class VoidArmorEvenementDeTickDesBottesProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 40, (int) (1 + DeepIntoTheVoidModVariables.MapVariables.get(world).MULTIPLICATEUR + DeepIntoTheVoidModVariables.MapVariables.get(world).multiplicateur2), false, false));
	}
}