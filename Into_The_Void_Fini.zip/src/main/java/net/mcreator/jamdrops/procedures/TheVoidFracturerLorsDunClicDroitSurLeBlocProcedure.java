package net.mcreator.jamdrops.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.jamdrops.network.DeepIntoTheVoidModVariables;
import net.mcreator.jamdrops.init.DeepIntoTheVoidModItems;
import net.mcreator.jamdrops.init.DeepIntoTheVoidModBlocks;
import net.mcreator.jamdrops.DeepIntoTheVoidMod;

public class TheVoidFracturerLorsDunClicDroitSurLeBlocProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == DeepIntoTheVoidModItems.VOID_CORE.get()) {
			DeepIntoTheVoidModVariables.MapVariables.get(world).XVF = x;
			DeepIntoTheVoidModVariables.MapVariables.get(world).YVF = y;
			DeepIntoTheVoidModVariables.MapVariables.get(world).ZVF = z;
			DeepIntoTheVoidModVariables.MapVariables.get(world).markSyncDirty();
			if (entity instanceof Player _player)
				_player.getCooldowns().addCooldown((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem(), 72000);
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("block.respawn_anchor.charge")), SoundSource.BLOCKS, 1, 3);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("block.respawn_anchor.charge")), SoundSource.BLOCKS, 1, 3, false);
				}
			}
			if (world instanceof ServerLevel _level)
				_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
						"weather thunder");
			DeepIntoTheVoidMod.queueServerWork(60, () -> {
				DeepIntoTheVoidModVariables.MapVariables.get(world).Tonner = true;
				DeepIntoTheVoidModVariables.MapVariables.get(world).markSyncDirty();
				DeepIntoTheVoidMod.queueServerWork(100, () -> {
					DeepIntoTheVoidModVariables.MapVariables.get(world).Tonner = false;
					DeepIntoTheVoidModVariables.MapVariables.get(world).markSyncDirty();
					DeepIntoTheVoidMod.queueServerWork(20, () -> {
						if (world instanceof Level _level) {
							if (!_level.isClientSide()) {
								_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("entity.zombie.break_wooden_door")), SoundSource.AMBIENT, 10, 4);
							} else {
								_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("entity.zombie.break_wooden_door")), SoundSource.AMBIENT, 10, 4, false);
							}
						}
						DeepIntoTheVoidMod.queueServerWork(30, () -> {
							if (world instanceof Level _level && !_level.isClientSide())
								_level.explode(null, x, (y + 2), z, 2, Level.ExplosionInteraction.BLOCK);
							world.setBlock(BlockPos.containing(x, y + 2, z), DeepIntoTheVoidModBlocks.VOID_PORTAL.get().defaultBlockState(), 3);
						});
						if (world instanceof ServerLevel _level)
							_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
									"weather clear");
						world.setBlock(BlockPos.containing(x, y, z), Blocks.AIR.defaultBlockState(), 3);
						world.setBlock(BlockPos.containing(x, y, z), Blocks.BEDROCK.defaultBlockState(), 3);
					});
				});
			});
		}
	}
}