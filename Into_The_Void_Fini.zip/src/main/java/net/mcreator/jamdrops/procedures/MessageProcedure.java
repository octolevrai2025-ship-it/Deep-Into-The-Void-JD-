package net.mcreator.jamdrops.procedures;

import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;

import net.mcreator.jamdrops.network.DeepIntoTheVoidModVariables;

import javax.annotation.Nullable;

@EventBusSubscriber
public class MessageProcedure {
	@SubscribeEvent
	public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
		execute(event, event.getEntity().level());
	}

	public static void execute(LevelAccessor world) {
		execute(null, world);
	}

	private static void execute(@Nullable Event event, LevelAccessor world) {
		if (DeepIntoTheVoidModVariables.MapVariables.get(world).message == true) {
			if (world instanceof ServerLevel _level) {
				_level.getServer().getPlayerList()
						.broadcastSystemMessage(Component.literal("Si vous \u00EAtes bloqu\u00E9 appuyez sur [,] pour obtenir des guides").withColor(0xccffff).withStyle(ChatFormatting.BOLD).withStyle(ChatFormatting.UNDERLINE), false);
			}
			DeepIntoTheVoidModVariables.MapVariables.get(world).message = false;
			DeepIntoTheVoidModVariables.MapVariables.get(world).markSyncDirty();
		}
	}
}