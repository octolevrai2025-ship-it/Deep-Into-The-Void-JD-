package net.mcreator.jamdrops.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.jamdrops.network.DeepIntoTheVoidModVariables;

public class VoidgolemQuandLentiteEstBlesseeProcedure {
	public static void execute(LevelAccessor world, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		DeepIntoTheVoidModVariables.MapVariables.get(world).Vie_Golem = DeepIntoTheVoidModVariables.MapVariables.get(world).Vie_Golem - 9;
		DeepIntoTheVoidModVariables.MapVariables.get(world).markSyncDirty();
		if (DeepIntoTheVoidModVariables.MapVariables.get(world).Vie_Golem < 325) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 100, 0, false, false));
		}
		if (DeepIntoTheVoidModVariables.MapVariables.get(world).Vie_Golem < 270) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 100, 1, false, false));
		}
		if (DeepIntoTheVoidModVariables.MapVariables.get(world).Vie_Golem < 125) {
			if (sourceentity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 210, 1, false, false));
		}
		if (DeepIntoTheVoidModVariables.MapVariables.get(world).Vie_Golem < 0) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 100, 1, false, true));
		}
	}
}