package net.mcreator.jamdrops.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.jamdrops.network.DeepIntoTheVoidModVariables;

public class VoidSwordQuandUneEntiteVivanteEstFrappeeAvecLoutilProcedure {
	public static void execute(LevelAccessor world) {
		DeepIntoTheVoidModVariables.MapVariables.get(world).combot = DeepIntoTheVoidModVariables.MapVariables.get(world).combot + 1;
		DeepIntoTheVoidModVariables.MapVariables.get(world).markSyncDirty();
	}
}