package net.mcreator.jamdrops.procedures;

import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;

import net.mcreator.jamdrops.network.DeepIntoTheVoidModVariables;

public class GuideRToucheEnfonceeProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (DeepIntoTheVoidModVariables.MapVariables.get(world).activable == true) {
			DeepIntoTheVoidModVariables.MapVariables.get(world).activable = false;
			DeepIntoTheVoidModVariables.MapVariables.get(world).markSyncDirty();
			if (world instanceof ServerLevel _serverworld) {
				StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("deep_into_the_void", "guide"));
				if (template != null) {
					template.placeInWorld(_serverworld, BlockPos.containing(x, y, z), BlockPos.containing(x, y, z), new StructurePlaceSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
				}
			}
		}
	}
}