package net.mcreator.jamdrops.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;

import net.mcreator.jamdrops.network.DeepIntoTheVoidModVariables;

public class VoidAxeQuandUneEntiteVivanteEstFrappeeAvecLoutilProcedure {
	public static void execute(LevelAccessor world, Entity sourceentity) {
		if (sourceentity == null)
			return;
		DeepIntoTheVoidModVariables.MapVariables.get(world).Insantderegen = DeepIntoTheVoidModVariables.MapVariables.get(world).Insantderegen + 1;
		DeepIntoTheVoidModVariables.MapVariables.get(world).markSyncDirty();
		if (DeepIntoTheVoidModVariables.MapVariables.get(world).Insantderegen >= 5) {
			if (world instanceof ServerLevel _level) {
				_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("Heal").withColor(0x33ff33), false);
			}
			if (sourceentity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.HEAL, 1, (int) (0 + DeepIntoTheVoidModVariables.MapVariables.get(world).MULTIPLICATEUR + DeepIntoTheVoidModVariables.MapVariables.get(world).multiplicateur2), false, false));
			DeepIntoTheVoidModVariables.MapVariables.get(world).Insantderegen = 0;
			DeepIntoTheVoidModVariables.MapVariables.get(world).markSyncDirty();
		}
	}
}