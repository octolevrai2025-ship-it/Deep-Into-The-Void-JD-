package net.mcreator.jamdrops.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.jamdrops.network.DeepIntoTheVoidModVariables;

public class ShinyGolemLorsDeLapparitionInitialeDeLentiteProcedure {
	public static void execute(LevelAccessor world) {
		DeepIntoTheVoidModVariables.MapVariables.get(world).Vie_golem2 = 400;
		DeepIntoTheVoidModVariables.MapVariables.get(world).markSyncDirty();
	}
}