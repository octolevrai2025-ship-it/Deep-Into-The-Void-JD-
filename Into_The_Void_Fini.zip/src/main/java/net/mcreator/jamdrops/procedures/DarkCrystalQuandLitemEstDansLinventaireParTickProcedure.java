package net.mcreator.jamdrops.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.server.level.ServerLevel;

import net.mcreator.jamdrops.network.DeepIntoTheVoidModVariables;
import net.mcreator.jamdrops.DeepIntoTheVoidMod;

public class DarkCrystalQuandLitemEstDansLinventaireParTickProcedure {
	public static void execute(LevelAccessor world, ItemStack itemstack) {
		DeepIntoTheVoidModVariables.MapVariables.get(world).MULTIPLICATEUR = 2;
		DeepIntoTheVoidModVariables.MapVariables.get(world).markSyncDirty();
		if (world instanceof ServerLevel _level) {
			itemstack.hurtAndBreak(1, _level, null, _stkprov -> {
			});
		}
		DeepIntoTheVoidMod.queueServerWork(20, () -> {
			DeepIntoTheVoidModVariables.MapVariables.get(world).MULTIPLICATEUR = 0;
			DeepIntoTheVoidModVariables.MapVariables.get(world).markSyncDirty();
		});
	}
}