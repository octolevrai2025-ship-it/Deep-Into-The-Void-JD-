package net.mcreator.jamdrops.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;

import net.mcreator.jamdrops.network.DeepIntoTheVoidModVariables;

public class VoidSwordLorsqueVousCliquezAvecLeBoutonDroitDeLaSourisSurUnBlocProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (DeepIntoTheVoidModVariables.MapVariables.get(world).combot >= 10) {
			if (world instanceof ServerLevel _level) {
				_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("strength").withColor(0xff0000), false);
			}
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,
						(int) (0 + DeepIntoTheVoidModVariables.MapVariables.get(world).combot * 6 + DeepIntoTheVoidModVariables.MapVariables.get(world).MULTIPLICATEUR + DeepIntoTheVoidModVariables.MapVariables.get(world).multiplicateur2),
						(int) (2 + DeepIntoTheVoidModVariables.MapVariables.get(world).MULTIPLICATEUR + DeepIntoTheVoidModVariables.MapVariables.get(world).multiplicateur2), false, false));
			DeepIntoTheVoidModVariables.MapVariables.get(world).combot = 0;
			DeepIntoTheVoidModVariables.MapVariables.get(world).markSyncDirty();
		}
	}
}