package net.mcreator.jamdrops.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;

import net.mcreator.jamdrops.network.DeepIntoTheVoidModVariables;

public class ShinyGolemQuandLeJoueurEntreEnCollisionAvecLentiteProcedure {
	public static void execute(LevelAccessor world, Entity sourceentity) {
		if (sourceentity == null)
			return;
		if (DeepIntoTheVoidModVariables.MapVariables.get(world).Vie_golem2 < 0) {
			sourceentity.hurt(new DamageSource(world.holderOrThrow(DamageTypes.MOB_ATTACK_NO_AGGRO)), 10);
		}
	}
}