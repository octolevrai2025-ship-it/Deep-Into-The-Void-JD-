package net.mcreator.jamdrops.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.jamdrops.network.DeepIntoTheVoidModVariables;

public class VoidgolemLorsDeLapparitionInitialeDeLentiteProcedure {
	public static void execute(LevelAccessor world) {
		DeepIntoTheVoidModVariables.MapVariables.get(world).Vie_Golem = 400;
		DeepIntoTheVoidModVariables.MapVariables.get(world).markSyncDirty();
	}
}