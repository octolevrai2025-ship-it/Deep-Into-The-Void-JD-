package net.mcreator.jamdrops.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.jamdrops.network.DeepIntoTheVoidModVariables;

public class PowerQuandLeffetExpireProcedure {
	public static void execute(LevelAccessor world) {
		DeepIntoTheVoidModVariables.MapVariables.get(world).multiplicateur2 = 0;
		DeepIntoTheVoidModVariables.MapVariables.get(world).markSyncDirty();
	}
}