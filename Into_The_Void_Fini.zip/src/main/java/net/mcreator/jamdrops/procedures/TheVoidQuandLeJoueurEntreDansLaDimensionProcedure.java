package net.mcreator.jamdrops.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;

public class TheVoidQuandLeJoueurEntreDansLaDimensionProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		world.setBlock(BlockPos.containing(entity.getX(), entity.getY(), entity.getZ()), Blocks.AIR.defaultBlockState(), 3);
		world.setBlock(BlockPos.containing(entity.getX() + 0, entity.getY() + 1, entity.getZ() + 0), Blocks.AIR.defaultBlockState(), 3);
		world.setBlock(BlockPos.containing(entity.getX() + 0, entity.getY() - 1, entity.getZ() + 0), Blocks.AIR.defaultBlockState(), 3);
		world.setBlock(BlockPos.containing(entity.getX() + 1, entity.getY() - 1, entity.getZ() + 1), Blocks.AIR.defaultBlockState(), 3);
		world.setBlock(BlockPos.containing(entity.getX() + 1, entity.getY() + 0, entity.getZ() + 0), Blocks.AIR.defaultBlockState(), 3);
		world.setBlock(BlockPos.containing(entity.getX() + 0, entity.getY() + 0, entity.getZ() + 1), Blocks.AIR.defaultBlockState(), 3);
	}
}