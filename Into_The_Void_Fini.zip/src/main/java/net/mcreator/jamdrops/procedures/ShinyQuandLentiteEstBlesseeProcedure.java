package net.mcreator.jamdrops.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.jamdrops.network.DeepIntoTheVoidModVariables;

public class ShinyQuandLentiteEstBlesseeProcedure {
	public static void execute(LevelAccessor world, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		DeepIntoTheVoidModVariables.MapVariables.get(world).Vie_golem2 = DeepIntoTheVoidModVariables.MapVariables.get(world).Vie_golem2 - 9;
		DeepIntoTheVoidModVariables.MapVariables.get(world).markSyncDirty();
		if (DeepIntoTheVoidModVariables.MapVariables.get(world).Vie_golem2 < 325) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 40, 0, false, false));
		}
		if (DeepIntoTheVoidModVariables.MapVariables.get(world).Vie_golem2 < 270) {
			if (sourceentity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20, 1, false, false));
		}
		if (DeepIntoTheVoidModVariables.MapVariables.get(world).Vie_golem2 < 125) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 80, 2, false, false));
		}
		if (DeepIntoTheVoidModVariables.MapVariables.get(world).Vie_golem2 < 0) {
			if (sourceentity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.HARM, 1, 0, false, false));
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.GLOWING, 60, 0, false, false));
		}
	}
}