package net.mcreator.jamdrops.procedures;

import net.neoforged.neoforge.event.tick.LevelTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.EntityType;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

import net.mcreator.jamdrops.network.DeepIntoTheVoidModVariables;

import javax.annotation.Nullable;

@EventBusSubscriber
public class EclairesProcedure {
	@SubscribeEvent
	public static void onWorldTick(LevelTickEvent.Post event) {
		execute(event, event.getLevel());
	}

	public static void execute(LevelAccessor world) {
		execute(null, world);
	}

	private static void execute(@Nullable Event event, LevelAccessor world) {
		if (DeepIntoTheVoidModVariables.MapVariables.get(world).Tonner == true) {
			if (world instanceof ServerLevel _level) {
				LightningBolt entityToSpawn = EntityType.LIGHTNING_BOLT.create(_level);
				entityToSpawn.moveTo(
						Vec3.atBottomCenterOf(BlockPos.containing(DeepIntoTheVoidModVariables.MapVariables.get(world).XVF + 4, DeepIntoTheVoidModVariables.MapVariables.get(world).YVF + 13, DeepIntoTheVoidModVariables.MapVariables.get(world).ZVF)));;
				_level.addFreshEntity(entityToSpawn);
			}
			if (world instanceof ServerLevel _level) {
				LightningBolt entityToSpawn = EntityType.LIGHTNING_BOLT.create(_level);
				entityToSpawn.moveTo(
						Vec3.atBottomCenterOf(BlockPos.containing(DeepIntoTheVoidModVariables.MapVariables.get(world).XVF - 4, DeepIntoTheVoidModVariables.MapVariables.get(world).YVF + 13, DeepIntoTheVoidModVariables.MapVariables.get(world).ZVF)));;
				_level.addFreshEntity(entityToSpawn);
			}
			if (world instanceof ServerLevel _level) {
				LightningBolt entityToSpawn = EntityType.LIGHTNING_BOLT.create(_level);
				entityToSpawn.moveTo(
						Vec3.atBottomCenterOf(BlockPos.containing(DeepIntoTheVoidModVariables.MapVariables.get(world).XVF, DeepIntoTheVoidModVariables.MapVariables.get(world).YVF + 13, DeepIntoTheVoidModVariables.MapVariables.get(world).ZVF + 4)));;
				_level.addFreshEntity(entityToSpawn);
			}
			if (world instanceof ServerLevel _level) {
				LightningBolt entityToSpawn = EntityType.LIGHTNING_BOLT.create(_level);
				entityToSpawn.moveTo(
						Vec3.atBottomCenterOf(BlockPos.containing(DeepIntoTheVoidModVariables.MapVariables.get(world).XVF, DeepIntoTheVoidModVariables.MapVariables.get(world).YVF + 13, DeepIntoTheVoidModVariables.MapVariables.get(world).ZVF - 4)));;
				_level.addFreshEntity(entityToSpawn);
			}
		}
	}
}