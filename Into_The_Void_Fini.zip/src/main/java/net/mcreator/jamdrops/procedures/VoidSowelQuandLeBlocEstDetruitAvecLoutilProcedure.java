package net.mcreator.jamdrops.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.jamdrops.network.DeepIntoTheVoidModVariables;

public class VoidSowelQuandLeBlocEstDetruitAvecLoutilProcedure {
	public static void execute(LevelAccessor world) {
		DeepIntoTheVoidModVariables.MapVariables.get(world).blocscasser = DeepIntoTheVoidModVariables.MapVariables.get(world).blocscasser + 1;
		DeepIntoTheVoidModVariables.MapVariables.get(world).markSyncDirty();
	}
}