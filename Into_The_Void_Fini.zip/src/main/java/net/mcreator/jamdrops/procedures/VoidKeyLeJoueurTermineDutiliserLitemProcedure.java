package net.mcreator.jamdrops.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.server.level.ServerLevel;

public class VoidKeyLeJoueurTermineDutiliserLitemProcedure {
	public static void execute(LevelAccessor world, ItemStack itemstack) {
		if (world instanceof ServerLevel _level) {
			itemstack.hurtAndBreak(101, _level, null, _stkprov -> {
			});
		}
	}
}