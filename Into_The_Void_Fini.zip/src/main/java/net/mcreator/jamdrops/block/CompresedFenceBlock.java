package net.mcreator.jamdrops.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.FenceBlock;

public class CompresedFenceBlock extends FenceBlock {
	public CompresedFenceBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.WOOD).strength(8f, 30f).forceSolidOn());
	}
}