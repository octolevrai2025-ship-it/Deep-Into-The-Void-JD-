package net.mcreator.jamdrops.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class BurnedCobbleBlock extends Block {
	public BurnedCobbleBlock() {
		super(BlockBehaviour.Properties.of().strength(1.95f, 1.5f));
	}
}