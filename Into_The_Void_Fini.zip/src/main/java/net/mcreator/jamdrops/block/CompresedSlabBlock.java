package net.mcreator.jamdrops.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.SlabBlock;

public class CompresedSlabBlock extends SlabBlock {
	public CompresedSlabBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.WOOD).strength(8f, 30f));
	}
}