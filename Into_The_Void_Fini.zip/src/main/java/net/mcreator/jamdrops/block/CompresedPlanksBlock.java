package net.mcreator.jamdrops.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;

public class CompresedPlanksBlock extends Block {
	public CompresedPlanksBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.WOOD).strength(8f, 30f));
	}
}