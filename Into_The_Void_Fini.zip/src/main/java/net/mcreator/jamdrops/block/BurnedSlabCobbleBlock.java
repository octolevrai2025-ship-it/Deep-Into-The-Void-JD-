package net.mcreator.jamdrops.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SlabBlock;

public class BurnedSlabCobbleBlock extends SlabBlock {
	public BurnedSlabCobbleBlock() {
		super(BlockBehaviour.Properties.of().strength(1.95f, 1.5f));
	}
}