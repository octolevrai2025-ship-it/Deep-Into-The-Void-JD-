package net.mcreator.jamdrops.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.WallBlock;

public class BurnedWallCobbleBlock extends WallBlock {
	public BurnedWallCobbleBlock() {
		super(BlockBehaviour.Properties.of().strength(1.95f, 1.5f).forceSolidOn());
	}
}