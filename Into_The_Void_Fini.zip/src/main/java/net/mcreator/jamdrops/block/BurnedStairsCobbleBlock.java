package net.mcreator.jamdrops.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.Blocks;

public class BurnedStairsCobbleBlock extends StairBlock {
	public BurnedStairsCobbleBlock() {
		super(Blocks.AIR.defaultBlockState(), BlockBehaviour.Properties.of().strength(1.95f, 1.5f));
	}

	@Override
	public float getExplosionResistance() {
		return 1.5f;
	}
}