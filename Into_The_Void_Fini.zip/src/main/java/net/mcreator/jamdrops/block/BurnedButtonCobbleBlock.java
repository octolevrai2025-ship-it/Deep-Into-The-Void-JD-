package net.mcreator.jamdrops.block;

import net.minecraft.world.level.block.state.properties.BlockSetType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.ButtonBlock;

public class BurnedButtonCobbleBlock extends ButtonBlock {
	public BurnedButtonCobbleBlock() {
		super(BlockSetType.STONE, 20, BlockBehaviour.Properties.of().strength(1.95f, 1.5f));
	}
}