package net.mcreator.jamdrops.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Blocks;

public class CompresedStairsBlock extends StairBlock {
	public CompresedStairsBlock() {
		super(Blocks.AIR.defaultBlockState(), BlockBehaviour.Properties.of().sound(SoundType.WOOD).strength(8f, 30f));
	}

	@Override
	public float getExplosionResistance() {
		return 30f;
	}
}