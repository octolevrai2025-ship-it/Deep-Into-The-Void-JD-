package net.mcreator.jamdrops.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.core.Holder;

import net.mcreator.jamdrops.init.DeepIntoTheVoidModBiomes;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements DeepIntoTheVoidModBiomes.DeepIntoTheVoidModNoiseGeneratorSettings {
	@Unique
	private Holder<DimensionType> deep_into_the_void_dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public SurfaceRules.RuleSource surfaceRule(Operation<SurfaceRules.RuleSource> original) {
		SurfaceRules.RuleSource retval = original.call();
		if (this.deep_into_the_void_dimensionTypeReference != null) {
			retval = DeepIntoTheVoidModBiomes.adaptSurfaceRule(retval, this.deep_into_the_void_dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void setdeep_into_the_voidDimensionTypeReference(Holder<DimensionType> dimensionType) {
		this.deep_into_the_void_dimensionTypeReference = dimensionType;
	}
}