/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jamdrops.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.jamdrops.client.renderer.VoidgolemRenderer;
import net.mcreator.jamdrops.client.renderer.VoidPillagerRenderer;
import net.mcreator.jamdrops.client.renderer.VoidPillager2Renderer;
import net.mcreator.jamdrops.client.renderer.AnciengolemRenderer;

@EventBusSubscriber(Dist.CLIENT)
public class DeepIntoTheVoidModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(DeepIntoTheVoidModEntities.VOIDGOLEM.get(), VoidgolemRenderer::new);
		event.registerEntityRenderer(DeepIntoTheVoidModEntities.ANCIENGOLEM.get(), AnciengolemRenderer::new);
		event.registerEntityRenderer(DeepIntoTheVoidModEntities.VOID_PILLAGER.get(), VoidPillagerRenderer::new);
		event.registerEntityRenderer(DeepIntoTheVoidModEntities.VOID_PILLAGER_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(DeepIntoTheVoidModEntities.VOID_PILLAGER_2.get(), VoidPillager2Renderer::new);
	}
}