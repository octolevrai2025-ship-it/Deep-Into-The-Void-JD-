/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jamdrops.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.jamdrops.client.model.Modelvoidgolem;
import net.mcreator.jamdrops.client.model.Modelportaille;
import net.mcreator.jamdrops.client.model.ModelVoidPillager;
import net.mcreator.jamdrops.client.model.ModelGolemAncien;

@EventBusSubscriber(Dist.CLIENT)
public class DeepIntoTheVoidModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modelportaille.LAYER_LOCATION, Modelportaille::createBodyLayer);
		event.registerLayerDefinition(ModelVoidPillager.LAYER_LOCATION, ModelVoidPillager::createBodyLayer);
		event.registerLayerDefinition(ModelGolemAncien.LAYER_LOCATION, ModelGolemAncien::createBodyLayer);
		event.registerLayerDefinition(Modelvoidgolem.LAYER_LOCATION, Modelvoidgolem::createBodyLayer);
	}
}