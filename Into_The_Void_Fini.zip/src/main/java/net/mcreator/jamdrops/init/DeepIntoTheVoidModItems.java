/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jamdrops.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.DoubleHighBlockItem;
import net.minecraft.world.item.BlockItem;

import net.mcreator.jamdrops.item.*;
import net.mcreator.jamdrops.DeepIntoTheVoidMod;

public class DeepIntoTheVoidModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(DeepIntoTheVoidMod.MODID);
	public static final DeferredItem<Item> VOID_SAND;
	public static final DeferredItem<Item> COMPACTED_STONE;
	public static final DeferredItem<Item> COMPACTED_LOG;
	public static final DeferredItem<Item> DARK_GRASS;
	public static final DeferredItem<Item> FLOWER_OF_DARKNESS;
	public static final DeferredItem<Item> DARKHIGHGRASS;
	public static final DeferredItem<Item> COMPACTED_DIRT;
	public static final DeferredItem<Item> THE_VOID;
	public static final DeferredItem<Item> VOID_ORE;
	public static final DeferredItem<Item> VOID_SHARD;
	public static final DeferredItem<Item> VOID_PICKAXE;
	public static final DeferredItem<Item> VOID_SWORD;
	public static final DeferredItem<Item> VOID_ARMOR_HELMET;
	public static final DeferredItem<Item> VOID_ARMOR_CHESTPLATE;
	public static final DeferredItem<Item> VOID_ARMOR_LEGGINGS;
	public static final DeferredItem<Item> VOID_ARMOR_BOOTS;
	public static final DeferredItem<Item> VOID_AXE;
	public static final DeferredItem<Item> VOID_HOE;
	public static final DeferredItem<Item> VOID_SOWEL;
	public static final DeferredItem<Item> DARK_CRYSTAL;
	public static final DeferredItem<Item> ASH_BLOCK;
	public static final DeferredItem<Item> BURNED_LOG;
	public static final DeferredItem<Item> BURNED_BUSH;
	public static final DeferredItem<Item> BURNED_COBBLE;
	public static final DeferredItem<Item> ASHSLAB;
	public static final DeferredItem<Item> BURNED_PLANKS;
	public static final DeferredItem<Item> BURNED_STAIRS_PLANKS;
	public static final DeferredItem<Item> BURNED_SLAB_PLANKS;
	public static final DeferredItem<Item> BURNED_FENCE_PLANKS;
	public static final DeferredItem<Item> BURNED_FENCE_GATE_PLANKS;
	public static final DeferredItem<Item> BURNED_STAIRS_COBBLE;
	public static final DeferredItem<Item> BURNED_SLAB_COBBLE;
	public static final DeferredItem<Item> BURNED_WALL_COBBLE;
	public static final DeferredItem<Item> BURNED_BUTTON_COBBLE;
	public static final DeferredItem<Item> UNKNOWN_CRYSTAL;
	public static final DeferredItem<Item> CORRUPT_CORE;
	public static final DeferredItem<Item> VOID_CORE;
	public static final DeferredItem<Item> THE_VOID_FRACTURER;
	public static final DeferredItem<Item> SHINY_LOG;
	public static final DeferredItem<Item> SHINY_BLUE_LEAVE;
	public static final DeferredItem<Item> SHINY_RED_LEAVE;
	public static final DeferredItem<Item> SHINY_PURPLE_LEAVE;
	public static final DeferredItem<Item> SHINY_GRASS_BLOCK;
	public static final DeferredItem<Item> SHINY_PLANKS;
	public static final DeferredItem<Item> SHINY_DIRT;
	public static final DeferredItem<Item> VOID_PORTAL;
	public static final DeferredItem<Item> GLOWING_FLOWER;
	public static final DeferredItem<Item> GRASS_OF_LIGHT;
	public static final DeferredItem<Item> SHINY_STONE;
	public static final DeferredItem<Item> SHINY_STAIRS;
	public static final DeferredItem<Item> SHINY_SLAB;
	public static final DeferredItem<Item> SHINY_FENCE;
	public static final DeferredItem<Item> SHINY_FENCE_GATE;
	public static final DeferredItem<Item> SHINY_PRESSURE_PLATE;
	public static final DeferredItem<Item> SHINY_BUTTON;
	public static final DeferredItem<Item> COMPRESED_PLANKS;
	public static final DeferredItem<Item> COMPRESED_STAIRS;
	public static final DeferredItem<Item> COMPRESED_SLAB;
	public static final DeferredItem<Item> COMPRESED_FENCE;
	public static final DeferredItem<Item> COMPRESED_FENCE_GATE;
	public static final DeferredItem<Item> COMPRESED_PRESSURE_PLATE;
	public static final DeferredItem<Item> COMPRESED_BUTTON;
	public static final DeferredItem<Item> BURNED_DOOR;
	public static final DeferredItem<Item> BURNED_TRAP_DOOR;
	public static final DeferredItem<Item> COMPRESED_DOOR;
	public static final DeferredItem<Item> COMPRESED_TRAP_DOOR;
	public static final DeferredItem<Item> SHINY_DOOR;
	public static final DeferredItem<Item> SHINY_TRAP_DOOR;
	public static final DeferredItem<Item> GOD_HEART;
	public static final DeferredItem<Item> SHINY_HEART;
	public static final DeferredItem<Item> DARK_HEART;
	public static final DeferredItem<Item> DARK_JAIL;
	public static final DeferredItem<Item> SHINY_JAIL;
	public static final DeferredItem<Item> VOID_KEY;
	public static final DeferredItem<Item> VOIDGOLEM_SPAWN_EGG;
	public static final DeferredItem<Item> ANCIENGOLEM_SPAWN_EGG;
	public static final DeferredItem<Item> VOID_PILLAGER_SPAWN_EGG;
	public static final DeferredItem<Item> VOID_PILLAGER_2_SPAWN_EGG;
	static {
		VOID_SAND = block(DeepIntoTheVoidModBlocks.VOID_SAND);
		COMPACTED_STONE = block(DeepIntoTheVoidModBlocks.COMPACTED_STONE);
		COMPACTED_LOG = block(DeepIntoTheVoidModBlocks.COMPACTED_LOG);
		DARK_GRASS = block(DeepIntoTheVoidModBlocks.DARK_GRASS);
		FLOWER_OF_DARKNESS = block(DeepIntoTheVoidModBlocks.FLOWER_OF_DARKNESS);
		DARKHIGHGRASS = block(DeepIntoTheVoidModBlocks.DARKHIGHGRASS);
		COMPACTED_DIRT = block(DeepIntoTheVoidModBlocks.COMPACTED_DIRT);
		THE_VOID = REGISTRY.register("the_void", TheVoidItem::new);
		VOID_ORE = block(DeepIntoTheVoidModBlocks.VOID_ORE);
		VOID_SHARD = REGISTRY.register("void_shard", VoidShardItem::new);
		VOID_PICKAXE = REGISTRY.register("void_pickaxe", VoidPickaxeItem::new);
		VOID_SWORD = REGISTRY.register("void_sword", VoidSwordItem::new);
		VOID_ARMOR_HELMET = REGISTRY.register("void_armor_helmet", VoidArmorItem.Helmet::new);
		VOID_ARMOR_CHESTPLATE = REGISTRY.register("void_armor_chestplate", VoidArmorItem.Chestplate::new);
		VOID_ARMOR_LEGGINGS = REGISTRY.register("void_armor_leggings", VoidArmorItem.Leggings::new);
		VOID_ARMOR_BOOTS = REGISTRY.register("void_armor_boots", VoidArmorItem.Boots::new);
		VOID_AXE = REGISTRY.register("void_axe", VoidAxeItem::new);
		VOID_HOE = REGISTRY.register("void_hoe", VoidHoeItem::new);
		VOID_SOWEL = REGISTRY.register("void_sowel", VoidSowelItem::new);
		DARK_CRYSTAL = REGISTRY.register("dark_crystal", DarkCrystalItem::new);
		ASH_BLOCK = block(DeepIntoTheVoidModBlocks.ASH_BLOCK);
		BURNED_LOG = block(DeepIntoTheVoidModBlocks.BURNED_LOG);
		BURNED_BUSH = block(DeepIntoTheVoidModBlocks.BURNED_BUSH);
		BURNED_COBBLE = block(DeepIntoTheVoidModBlocks.BURNED_COBBLE);
		ASHSLAB = block(DeepIntoTheVoidModBlocks.ASHSLAB);
		BURNED_PLANKS = block(DeepIntoTheVoidModBlocks.BURNED_PLANKS);
		BURNED_STAIRS_PLANKS = block(DeepIntoTheVoidModBlocks.BURNED_STAIRS_PLANKS);
		BURNED_SLAB_PLANKS = block(DeepIntoTheVoidModBlocks.BURNED_SLAB_PLANKS);
		BURNED_FENCE_PLANKS = block(DeepIntoTheVoidModBlocks.BURNED_FENCE_PLANKS);
		BURNED_FENCE_GATE_PLANKS = block(DeepIntoTheVoidModBlocks.BURNED_FENCE_GATE_PLANKS);
		BURNED_STAIRS_COBBLE = block(DeepIntoTheVoidModBlocks.BURNED_STAIRS_COBBLE);
		BURNED_SLAB_COBBLE = block(DeepIntoTheVoidModBlocks.BURNED_SLAB_COBBLE);
		BURNED_WALL_COBBLE = block(DeepIntoTheVoidModBlocks.BURNED_WALL_COBBLE);
		BURNED_BUTTON_COBBLE = block(DeepIntoTheVoidModBlocks.BURNED_BUTTON_COBBLE);
		UNKNOWN_CRYSTAL = REGISTRY.register("unknown_crystal", UnknownCrystalItem::new);
		CORRUPT_CORE = REGISTRY.register("corrupt_core", CorruptCoreItem::new);
		VOID_CORE = REGISTRY.register("void_core", VoidCoreItem::new);
		THE_VOID_FRACTURER = block(DeepIntoTheVoidModBlocks.THE_VOID_FRACTURER);
		SHINY_LOG = block(DeepIntoTheVoidModBlocks.SHINY_LOG);
		SHINY_BLUE_LEAVE = block(DeepIntoTheVoidModBlocks.SHINY_BLUE_LEAVE);
		SHINY_RED_LEAVE = block(DeepIntoTheVoidModBlocks.SHINY_RED_LEAVE);
		SHINY_PURPLE_LEAVE = block(DeepIntoTheVoidModBlocks.SHINY_PURPLE_LEAVE);
		SHINY_GRASS_BLOCK = block(DeepIntoTheVoidModBlocks.SHINY_GRASS_BLOCK);
		SHINY_PLANKS = block(DeepIntoTheVoidModBlocks.SHINY_PLANKS);
		SHINY_DIRT = block(DeepIntoTheVoidModBlocks.SHINY_DIRT);
		VOID_PORTAL = block(DeepIntoTheVoidModBlocks.VOID_PORTAL);
		GLOWING_FLOWER = block(DeepIntoTheVoidModBlocks.GLOWING_FLOWER);
		GRASS_OF_LIGHT = block(DeepIntoTheVoidModBlocks.GRASS_OF_LIGHT);
		SHINY_STONE = block(DeepIntoTheVoidModBlocks.SHINY_STONE);
		SHINY_STAIRS = block(DeepIntoTheVoidModBlocks.SHINY_STAIRS);
		SHINY_SLAB = block(DeepIntoTheVoidModBlocks.SHINY_SLAB);
		SHINY_FENCE = block(DeepIntoTheVoidModBlocks.SHINY_FENCE);
		SHINY_FENCE_GATE = block(DeepIntoTheVoidModBlocks.SHINY_FENCE_GATE);
		SHINY_PRESSURE_PLATE = block(DeepIntoTheVoidModBlocks.SHINY_PRESSURE_PLATE);
		SHINY_BUTTON = block(DeepIntoTheVoidModBlocks.SHINY_BUTTON);
		COMPRESED_PLANKS = block(DeepIntoTheVoidModBlocks.COMPRESED_PLANKS);
		COMPRESED_STAIRS = block(DeepIntoTheVoidModBlocks.COMPRESED_STAIRS);
		COMPRESED_SLAB = block(DeepIntoTheVoidModBlocks.COMPRESED_SLAB);
		COMPRESED_FENCE = block(DeepIntoTheVoidModBlocks.COMPRESED_FENCE);
		COMPRESED_FENCE_GATE = block(DeepIntoTheVoidModBlocks.COMPRESED_FENCE_GATE);
		COMPRESED_PRESSURE_PLATE = block(DeepIntoTheVoidModBlocks.COMPRESED_PRESSURE_PLATE);
		COMPRESED_BUTTON = block(DeepIntoTheVoidModBlocks.COMPRESED_BUTTON);
		BURNED_DOOR = doubleBlock(DeepIntoTheVoidModBlocks.BURNED_DOOR);
		BURNED_TRAP_DOOR = block(DeepIntoTheVoidModBlocks.BURNED_TRAP_DOOR);
		COMPRESED_DOOR = doubleBlock(DeepIntoTheVoidModBlocks.COMPRESED_DOOR);
		COMPRESED_TRAP_DOOR = block(DeepIntoTheVoidModBlocks.COMPRESED_TRAP_DOOR);
		SHINY_DOOR = doubleBlock(DeepIntoTheVoidModBlocks.SHINY_DOOR);
		SHINY_TRAP_DOOR = block(DeepIntoTheVoidModBlocks.SHINY_TRAP_DOOR);
		GOD_HEART = REGISTRY.register("god_heart", GodHeartItem::new);
		SHINY_HEART = REGISTRY.register("shiny_heart", ShinyHeartItem::new);
		DARK_HEART = REGISTRY.register("dark_heart", DarkHeartItem::new);
		DARK_JAIL = block(DeepIntoTheVoidModBlocks.DARK_JAIL);
		SHINY_JAIL = block(DeepIntoTheVoidModBlocks.SHINY_JAIL);
		VOID_KEY = REGISTRY.register("void_key", VoidKeyItem::new);
		VOIDGOLEM_SPAWN_EGG = REGISTRY.register("voidgolem_spawn_egg", () -> new DeferredSpawnEggItem(DeepIntoTheVoidModEntities.VOIDGOLEM, -13421773, -13434829, new Item.Properties()));
		ANCIENGOLEM_SPAWN_EGG = REGISTRY.register("anciengolem_spawn_egg", () -> new DeferredSpawnEggItem(DeepIntoTheVoidModEntities.ANCIENGOLEM, -26368, -16724788, new Item.Properties()));
		VOID_PILLAGER_SPAWN_EGG = REGISTRY.register("void_pillager_spawn_egg", () -> new DeferredSpawnEggItem(DeepIntoTheVoidModEntities.VOID_PILLAGER, -1, -1, new Item.Properties()));
		VOID_PILLAGER_2_SPAWN_EGG = REGISTRY.register("void_pillager_2_spawn_egg", () -> new DeferredSpawnEggItem(DeepIntoTheVoidModEntities.VOID_PILLAGER_2, -1, -1, new Item.Properties()));
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), properties));
	}

	private static DeferredItem<Item> doubleBlock(DeferredHolder<Block, Block> block) {
		return doubleBlock(block, new Item.Properties());
	}

	private static DeferredItem<Item> doubleBlock(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.register(block.getId().getPath(), () -> new DoubleHighBlockItem(block.get(), properties));
	}
}