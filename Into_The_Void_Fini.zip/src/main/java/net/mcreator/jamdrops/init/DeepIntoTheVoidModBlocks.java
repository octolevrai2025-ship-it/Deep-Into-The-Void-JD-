/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jamdrops.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.client.event.RegisterColorHandlersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.jamdrops.block.*;
import net.mcreator.jamdrops.DeepIntoTheVoidMod;

public class DeepIntoTheVoidModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(DeepIntoTheVoidMod.MODID);
	public static final DeferredBlock<Block> VOID_SAND;
	public static final DeferredBlock<Block> COMPACTED_STONE;
	public static final DeferredBlock<Block> COMPACTED_LOG;
	public static final DeferredBlock<Block> DARK_GRASS;
	public static final DeferredBlock<Block> FLOWER_OF_DARKNESS;
	public static final DeferredBlock<Block> DARKHIGHGRASS;
	public static final DeferredBlock<Block> COMPACTED_DIRT;
	public static final DeferredBlock<Block> THE_VOID_PORTAL;
	public static final DeferredBlock<Block> VOID_ORE;
	public static final DeferredBlock<Block> ASH_BLOCK;
	public static final DeferredBlock<Block> BURNED_LOG;
	public static final DeferredBlock<Block> BURNED_BUSH;
	public static final DeferredBlock<Block> BURNED_COBBLE;
	public static final DeferredBlock<Block> ASHSLAB;
	public static final DeferredBlock<Block> BURNED_PLANKS;
	public static final DeferredBlock<Block> BURNED_STAIRS_PLANKS;
	public static final DeferredBlock<Block> BURNED_SLAB_PLANKS;
	public static final DeferredBlock<Block> BURNED_FENCE_PLANKS;
	public static final DeferredBlock<Block> BURNED_FENCE_GATE_PLANKS;
	public static final DeferredBlock<Block> BURNED_STAIRS_COBBLE;
	public static final DeferredBlock<Block> BURNED_SLAB_COBBLE;
	public static final DeferredBlock<Block> BURNED_WALL_COBBLE;
	public static final DeferredBlock<Block> BURNED_BUTTON_COBBLE;
	public static final DeferredBlock<Block> THE_VOID_FRACTURER;
	public static final DeferredBlock<Block> SHINY_LOG;
	public static final DeferredBlock<Block> SHINY_BLUE_LEAVE;
	public static final DeferredBlock<Block> SHINY_RED_LEAVE;
	public static final DeferredBlock<Block> SHINY_PURPLE_LEAVE;
	public static final DeferredBlock<Block> SHINY_GRASS_BLOCK;
	public static final DeferredBlock<Block> SHINY_PLANKS;
	public static final DeferredBlock<Block> SHINY_DIRT;
	public static final DeferredBlock<Block> VOID_PORTAL;
	public static final DeferredBlock<Block> GLOWING_FLOWER;
	public static final DeferredBlock<Block> GRASS_OF_LIGHT;
	public static final DeferredBlock<Block> SHINY_STONE;
	public static final DeferredBlock<Block> SHINY_STAIRS;
	public static final DeferredBlock<Block> SHINY_SLAB;
	public static final DeferredBlock<Block> SHINY_FENCE;
	public static final DeferredBlock<Block> SHINY_FENCE_GATE;
	public static final DeferredBlock<Block> SHINY_PRESSURE_PLATE;
	public static final DeferredBlock<Block> SHINY_BUTTON;
	public static final DeferredBlock<Block> COMPRESED_PLANKS;
	public static final DeferredBlock<Block> COMPRESED_STAIRS;
	public static final DeferredBlock<Block> COMPRESED_SLAB;
	public static final DeferredBlock<Block> COMPRESED_FENCE;
	public static final DeferredBlock<Block> COMPRESED_FENCE_GATE;
	public static final DeferredBlock<Block> COMPRESED_PRESSURE_PLATE;
	public static final DeferredBlock<Block> COMPRESED_BUTTON;
	public static final DeferredBlock<Block> BURNED_DOOR;
	public static final DeferredBlock<Block> BURNED_TRAP_DOOR;
	public static final DeferredBlock<Block> COMPRESED_DOOR;
	public static final DeferredBlock<Block> COMPRESED_TRAP_DOOR;
	public static final DeferredBlock<Block> SHINY_DOOR;
	public static final DeferredBlock<Block> SHINY_TRAP_DOOR;
	public static final DeferredBlock<Block> DARK_JAIL;
	public static final DeferredBlock<Block> SHINY_JAIL;
	static {
		VOID_SAND = REGISTRY.register("void_sand", VoidSandBlock::new);
		COMPACTED_STONE = REGISTRY.register("compacted_stone", CompactedStoneBlock::new);
		COMPACTED_LOG = REGISTRY.register("compacted_log", CompactedLogBlock::new);
		DARK_GRASS = REGISTRY.register("dark_grass", DarkGrassBlock::new);
		FLOWER_OF_DARKNESS = REGISTRY.register("flower_of_darkness", FlowerOfDarknessBlock::new);
		DARKHIGHGRASS = REGISTRY.register("darkhighgrass", DarkhighgrassBlock::new);
		COMPACTED_DIRT = REGISTRY.register("compacted_dirt", CompactedDirtBlock::new);
		THE_VOID_PORTAL = REGISTRY.register("the_void_portal", TheVoidPortalBlock::new);
		VOID_ORE = REGISTRY.register("void_ore", VoidOreBlock::new);
		ASH_BLOCK = REGISTRY.register("ash_block", AshBlockBlock::new);
		BURNED_LOG = REGISTRY.register("burned_log", BurnedLogBlock::new);
		BURNED_BUSH = REGISTRY.register("burned_bush", BurnedBushBlock::new);
		BURNED_COBBLE = REGISTRY.register("burned_cobble", BurnedCobbleBlock::new);
		ASHSLAB = REGISTRY.register("ashslab", AshslabBlock::new);
		BURNED_PLANKS = REGISTRY.register("burned_planks", BurnedPlanksBlock::new);
		BURNED_STAIRS_PLANKS = REGISTRY.register("burned_stairs_planks", BurnedStairsPlanksBlock::new);
		BURNED_SLAB_PLANKS = REGISTRY.register("burned_slab_planks", BurnedSlabPlanksBlock::new);
		BURNED_FENCE_PLANKS = REGISTRY.register("burned_fence_planks", BurnedFencePlanksBlock::new);
		BURNED_FENCE_GATE_PLANKS = REGISTRY.register("burned_fence_gate_planks", BurnedFenceGatePlanksBlock::new);
		BURNED_STAIRS_COBBLE = REGISTRY.register("burned_stairs_cobble", BurnedStairsCobbleBlock::new);
		BURNED_SLAB_COBBLE = REGISTRY.register("burned_slab_cobble", BurnedSlabCobbleBlock::new);
		BURNED_WALL_COBBLE = REGISTRY.register("burned_wall_cobble", BurnedWallCobbleBlock::new);
		BURNED_BUTTON_COBBLE = REGISTRY.register("burned_button_cobble", BurnedButtonCobbleBlock::new);
		THE_VOID_FRACTURER = REGISTRY.register("the_void_fracturer", TheVoidFracturerBlock::new);
		SHINY_LOG = REGISTRY.register("shiny_log", ShinyLogBlock::new);
		SHINY_BLUE_LEAVE = REGISTRY.register("shiny_blue_leave", ShinyBlueLeaveBlock::new);
		SHINY_RED_LEAVE = REGISTRY.register("shiny_red_leave", ShinyRedLeaveBlock::new);
		SHINY_PURPLE_LEAVE = REGISTRY.register("shiny_purple_leave", ShinyPurpleLeaveBlock::new);
		SHINY_GRASS_BLOCK = REGISTRY.register("shiny_grass_block", ShinyGrassBlockBlock::new);
		SHINY_PLANKS = REGISTRY.register("shiny_planks", ShinyPlanksBlock::new);
		SHINY_DIRT = REGISTRY.register("shiny_dirt", ShinyDirtBlock::new);
		VOID_PORTAL = REGISTRY.register("void_portal", VoidPortalBlock::new);
		GLOWING_FLOWER = REGISTRY.register("glowing_flower", GlowingFlowerBlock::new);
		GRASS_OF_LIGHT = REGISTRY.register("grass_of_light", GrassOfLightBlock::new);
		SHINY_STONE = REGISTRY.register("shiny_stone", ShinyStoneBlock::new);
		SHINY_STAIRS = REGISTRY.register("shiny_stairs", ShinyStairsBlock::new);
		SHINY_SLAB = REGISTRY.register("shiny_slab", ShinySlabBlock::new);
		SHINY_FENCE = REGISTRY.register("shiny_fence", ShinyFenceBlock::new);
		SHINY_FENCE_GATE = REGISTRY.register("shiny_fence_gate", ShinyFenceGateBlock::new);
		SHINY_PRESSURE_PLATE = REGISTRY.register("shiny_pressure_plate", ShinyPressurePlateBlock::new);
		SHINY_BUTTON = REGISTRY.register("shiny_button", ShinyButtonBlock::new);
		COMPRESED_PLANKS = REGISTRY.register("compresed_planks", CompresedPlanksBlock::new);
		COMPRESED_STAIRS = REGISTRY.register("compresed_stairs", CompresedStairsBlock::new);
		COMPRESED_SLAB = REGISTRY.register("compresed_slab", CompresedSlabBlock::new);
		COMPRESED_FENCE = REGISTRY.register("compresed_fence", CompresedFenceBlock::new);
		COMPRESED_FENCE_GATE = REGISTRY.register("compresed_fence_gate", CompresedFenceGateBlock::new);
		COMPRESED_PRESSURE_PLATE = REGISTRY.register("compresed_pressure_plate", CompresedPressurePlateBlock::new);
		COMPRESED_BUTTON = REGISTRY.register("compresed_button", CompresedButtonBlock::new);
		BURNED_DOOR = REGISTRY.register("burned_door", BurnedDoorBlock::new);
		BURNED_TRAP_DOOR = REGISTRY.register("burned_trap_door", BurnedTrapDoorBlock::new);
		COMPRESED_DOOR = REGISTRY.register("compresed_door", CompresedDoorBlock::new);
		COMPRESED_TRAP_DOOR = REGISTRY.register("compresed_trap_door", CompresedTrapDoorBlock::new);
		SHINY_DOOR = REGISTRY.register("shiny_door", ShinyDoorBlock::new);
		SHINY_TRAP_DOOR = REGISTRY.register("shiny_trap_door", ShinyTrapDoorBlock::new);
		DARK_JAIL = REGISTRY.register("dark_jail", DarkJailBlock::new);
		SHINY_JAIL = REGISTRY.register("shiny_jail", ShinyJailBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	@EventBusSubscriber(Dist.CLIENT)
	public static class BlocksClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			DarkGrassBlock.blockColorLoad(event);
			FlowerOfDarknessBlock.blockColorLoad(event);
			DarkhighgrassBlock.blockColorLoad(event);
			ShinyGrassBlockBlock.blockColorLoad(event);
			GlowingFlowerBlock.blockColorLoad(event);
		}

		@SubscribeEvent
		public static void itemColorLoad(RegisterColorHandlersEvent.Item event) {
			DarkGrassBlock.itemColorLoad(event);
			FlowerOfDarknessBlock.itemColorLoad(event);
			DarkhighgrassBlock.itemColorLoad(event);
			ShinyGrassBlockBlock.itemColorLoad(event);
			GlowingFlowerBlock.itemColorLoad(event);
		}
	}
}