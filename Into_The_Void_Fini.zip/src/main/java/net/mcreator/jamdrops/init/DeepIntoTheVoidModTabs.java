/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jamdrops.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.jamdrops.DeepIntoTheVoidMod;

@EventBusSubscriber
public class DeepIntoTheVoidModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, DeepIntoTheVoidMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> DEEP_INTO_THE_VOID = REGISTRY.register("deep_into_the_void",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.deep_into_the_void.deep_into_the_void")).icon(() -> new ItemStack(DeepIntoTheVoidModItems.DARK_CRYSTAL.get())).displayItems((parameters, tabData) -> {
				tabData.accept(DeepIntoTheVoidModBlocks.VOID_SAND.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.COMPACTED_STONE.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.COMPACTED_LOG.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.DARK_GRASS.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.FLOWER_OF_DARKNESS.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.DARKHIGHGRASS.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.COMPACTED_DIRT.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.VOID_ORE.get().asItem());
				tabData.accept(DeepIntoTheVoidModItems.VOID_SHARD.get());
				tabData.accept(DeepIntoTheVoidModItems.VOID_PICKAXE.get());
				tabData.accept(DeepIntoTheVoidModItems.VOID_SWORD.get());
				tabData.accept(DeepIntoTheVoidModItems.VOID_ARMOR_HELMET.get());
				tabData.accept(DeepIntoTheVoidModItems.VOID_ARMOR_CHESTPLATE.get());
				tabData.accept(DeepIntoTheVoidModItems.VOID_ARMOR_LEGGINGS.get());
				tabData.accept(DeepIntoTheVoidModItems.VOID_ARMOR_BOOTS.get());
				tabData.accept(DeepIntoTheVoidModItems.VOID_AXE.get());
				tabData.accept(DeepIntoTheVoidModItems.VOID_HOE.get());
				tabData.accept(DeepIntoTheVoidModItems.VOID_SOWEL.get());
				tabData.accept(DeepIntoTheVoidModItems.DARK_CRYSTAL.get());
				tabData.accept(DeepIntoTheVoidModBlocks.ASH_BLOCK.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.BURNED_LOG.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.BURNED_BUSH.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.BURNED_COBBLE.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.BURNED_PLANKS.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.BURNED_STAIRS_PLANKS.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.BURNED_SLAB_PLANKS.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.BURNED_FENCE_PLANKS.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.BURNED_FENCE_GATE_PLANKS.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.BURNED_STAIRS_COBBLE.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.BURNED_SLAB_COBBLE.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.BURNED_WALL_COBBLE.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.BURNED_BUTTON_COBBLE.get().asItem());
				tabData.accept(DeepIntoTheVoidModItems.UNKNOWN_CRYSTAL.get());
				tabData.accept(DeepIntoTheVoidModItems.CORRUPT_CORE.get());
				tabData.accept(DeepIntoTheVoidModItems.VOID_CORE.get());
				tabData.accept(DeepIntoTheVoidModBlocks.SHINY_LOG.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.SHINY_BLUE_LEAVE.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.SHINY_RED_LEAVE.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.SHINY_PURPLE_LEAVE.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.SHINY_GRASS_BLOCK.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.SHINY_PLANKS.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.SHINY_DIRT.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.SHINY_STONE.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.SHINY_STAIRS.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.SHINY_SLAB.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.SHINY_FENCE.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.SHINY_FENCE_GATE.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.SHINY_PRESSURE_PLATE.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.SHINY_BUTTON.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.COMPRESED_PLANKS.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.COMPRESED_STAIRS.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.COMPRESED_SLAB.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.COMPRESED_FENCE.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.COMPRESED_FENCE_GATE.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.COMPRESED_PRESSURE_PLATE.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.COMPRESED_BUTTON.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.BURNED_DOOR.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.BURNED_TRAP_DOOR.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.COMPRESED_DOOR.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.COMPRESED_TRAP_DOOR.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.SHINY_DOOR.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.SHINY_TRAP_DOOR.get().asItem());
				tabData.accept(DeepIntoTheVoidModItems.SHINY_HEART.get());
				tabData.accept(DeepIntoTheVoidModItems.DARK_HEART.get());
				tabData.accept(DeepIntoTheVoidModBlocks.DARK_JAIL.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.SHINY_JAIL.get().asItem());
				tabData.accept(DeepIntoTheVoidModItems.VOID_KEY.get());
			}).build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(DeepIntoTheVoidModBlocks.VOID_SAND.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.COMPACTED_STONE.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.COMPACTED_LOG.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.DARK_GRASS.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.FLOWER_OF_DARKNESS.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.DARKHIGHGRASS.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.COMPACTED_DIRT.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.VOID_ORE.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.ASH_BLOCK.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.BURNED_LOG.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.BURNED_BUSH.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.BURNED_COBBLE.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.ASHSLAB.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.SHINY_LOG.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.SHINY_BLUE_LEAVE.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.SHINY_RED_LEAVE.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.SHINY_PURPLE_LEAVE.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.SHINY_GRASS_BLOCK.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.SHINY_DIRT.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.GLOWING_FLOWER.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.GRASS_OF_LIGHT.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.SHINY_STONE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(DeepIntoTheVoidModBlocks.COMPACTED_STONE.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.BURNED_LOG.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.BURNED_COBBLE.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.BURNED_PLANKS.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.BURNED_STAIRS_PLANKS.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.BURNED_SLAB_PLANKS.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.BURNED_FENCE_PLANKS.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.BURNED_FENCE_GATE_PLANKS.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.BURNED_STAIRS_COBBLE.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.BURNED_SLAB_COBBLE.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.BURNED_WALL_COBBLE.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.SHINY_LOG.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.SHINY_PLANKS.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.SHINY_STAIRS.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.SHINY_SLAB.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.SHINY_FENCE.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.SHINY_FENCE_GATE.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.COMPRESED_PLANKS.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.COMPRESED_STAIRS.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.COMPRESED_SLAB.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.COMPRESED_FENCE.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.COMPRESED_FENCE_GATE.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.BURNED_DOOR.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.BURNED_TRAP_DOOR.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.COMPRESED_DOOR.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.COMPRESED_TRAP_DOOR.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.SHINY_DOOR.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.SHINY_TRAP_DOOR.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(DeepIntoTheVoidModItems.THE_VOID.get());
			tabData.accept(DeepIntoTheVoidModItems.VOID_PICKAXE.get());
			tabData.accept(DeepIntoTheVoidModItems.VOID_AXE.get());
			tabData.accept(DeepIntoTheVoidModItems.VOID_HOE.get());
			tabData.accept(DeepIntoTheVoidModItems.VOID_SOWEL.get());
			tabData.accept(DeepIntoTheVoidModItems.DARK_CRYSTAL.get());
			tabData.accept(DeepIntoTheVoidModItems.VOID_CORE.get());
			tabData.accept(DeepIntoTheVoidModItems.VOID_KEY.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(DeepIntoTheVoidModItems.VOID_SHARD.get());
			tabData.accept(DeepIntoTheVoidModItems.UNKNOWN_CRYSTAL.get());
			tabData.accept(DeepIntoTheVoidModItems.CORRUPT_CORE.get());
			tabData.accept(DeepIntoTheVoidModItems.SHINY_HEART.get());
			tabData.accept(DeepIntoTheVoidModItems.DARK_HEART.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(DeepIntoTheVoidModItems.VOID_SWORD.get());
			tabData.accept(DeepIntoTheVoidModItems.VOID_ARMOR_HELMET.get());
			tabData.accept(DeepIntoTheVoidModItems.VOID_ARMOR_CHESTPLATE.get());
			tabData.accept(DeepIntoTheVoidModItems.VOID_ARMOR_LEGGINGS.get());
			tabData.accept(DeepIntoTheVoidModItems.VOID_ARMOR_BOOTS.get());
			tabData.accept(DeepIntoTheVoidModItems.VOID_AXE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(DeepIntoTheVoidModBlocks.BURNED_BUTTON_COBBLE.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.SHINY_PRESSURE_PLATE.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.SHINY_BUTTON.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.COMPRESED_PRESSURE_PLATE.get().asItem());
			tabData.accept(DeepIntoTheVoidModBlocks.COMPRESED_BUTTON.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.OP_BLOCKS) {
			if (tabData.hasPermissions()) {
				tabData.accept(DeepIntoTheVoidModBlocks.THE_VOID_FRACTURER.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.VOID_PORTAL.get().asItem());
				tabData.accept(DeepIntoTheVoidModItems.GOD_HEART.get());
				tabData.accept(DeepIntoTheVoidModBlocks.DARK_JAIL.get().asItem());
				tabData.accept(DeepIntoTheVoidModBlocks.SHINY_JAIL.get().asItem());
			}
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(DeepIntoTheVoidModItems.VOIDGOLEM_SPAWN_EGG.get());
			tabData.accept(DeepIntoTheVoidModItems.ANCIENGOLEM_SPAWN_EGG.get());
			tabData.accept(DeepIntoTheVoidModItems.VOID_PILLAGER_SPAWN_EGG.get());
			tabData.accept(DeepIntoTheVoidModItems.VOID_PILLAGER_2_SPAWN_EGG.get());
		}
	}
}