/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jamdrops.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.registries.Registries;

import net.mcreator.jamdrops.entity.VoidgolemEntity;
import net.mcreator.jamdrops.entity.VoidPillagerEntityProjectile;
import net.mcreator.jamdrops.entity.VoidPillagerEntity;
import net.mcreator.jamdrops.entity.VoidPillager2Entity;
import net.mcreator.jamdrops.entity.AnciengolemEntity;
import net.mcreator.jamdrops.DeepIntoTheVoidMod;

@EventBusSubscriber
public class DeepIntoTheVoidModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, DeepIntoTheVoidMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<VoidgolemEntity>> VOIDGOLEM = register("voidgolem",
			EntityType.Builder.<VoidgolemEntity>of(VoidgolemEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune()

					.sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<AnciengolemEntity>> ANCIENGOLEM = register("anciengolem",
			EntityType.Builder.<AnciengolemEntity>of(AnciengolemEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune()

					.sized(1f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<VoidPillagerEntity>> VOID_PILLAGER = register("void_pillager",
			EntityType.Builder.<VoidPillagerEntity>of(VoidPillagerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<VoidPillagerEntityProjectile>> VOID_PILLAGER_PROJECTILE = register("projectile_void_pillager",
			EntityType.Builder.<VoidPillagerEntityProjectile>of(VoidPillagerEntityProjectile::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<VoidPillager2Entity>> VOID_PILLAGER_2 = register("void_pillager_2",
			EntityType.Builder.<VoidPillager2Entity>of(VoidPillager2Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.6f, 1.8f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(RegisterSpawnPlacementsEvent event) {
		VoidgolemEntity.init(event);
		AnciengolemEntity.init(event);
		VoidPillagerEntity.init(event);
		VoidPillager2Entity.init(event);
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(VOIDGOLEM.get(), VoidgolemEntity.createAttributes().build());
		event.put(ANCIENGOLEM.get(), AnciengolemEntity.createAttributes().build());
		event.put(VOID_PILLAGER.get(), VoidPillagerEntity.createAttributes().build());
		event.put(VOID_PILLAGER_2.get(), VoidPillager2Entity.createAttributes().build());
	}
}